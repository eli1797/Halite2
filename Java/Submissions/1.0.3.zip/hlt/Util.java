package hlt;

import java.util.Map;

public class Util {

    public static int angleRadToDegClipped(final double angleRad) {
        final long degUnclipped = Math.round(Math.toDegrees(angleRad));
        // Make sure return value is in [0, 360) as required by game engine.
        return (int) (((degUnclipped % 360L) + 360L) % 360L);
    }

    /**
     * Returns the nearest planet not owned by anyone
     * @param ship The ship that's looking for a nearby planet
     * @param gameMap The shared 2D playing board
     * @return Planet The closest unoccupied planet
     */
    public static Planet nearestUnownedPlanet(Ship ship, GameMap gameMap) {
        Planet nearest = null;
        Map<Double, Entity> entityMap = gameMap.nearbyEntitiesByDistance(ship);

        if (entityMap != null && !(entityMap.isEmpty())) {
            Double shortDist = null;
            for (Map.Entry<Double, Entity> entry : entityMap.entrySet()) {
                Entity ent = entry.getValue();
                Double dist = entry.getKey();
                if (!(ent instanceof Planet)) {
                    //skip this iteration
                    continue;
                } else {
                    Planet temp = (Planet) ent;
                    if (temp.isOwned()) {
                        //skip this iteration
                        continue;
                    }
                    if (shortDist == null) {
                        shortDist = dist;
                        nearest = temp;
                    } else if (shortDist > dist) {
                        nearest = temp;
                    }
                }
            }
        }
        return nearest;
    }
}
