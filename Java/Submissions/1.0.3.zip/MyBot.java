import hlt.*;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class MyBot {

    public static void main(final String[] args) {
        final Networking networking = new Networking();
        final GameMap gameMap = networking.initialize("Tamagocchi");
        final int playerID = gameMap.getMyPlayerId();
        Map<Planet, Integer> squads = new TreeMap<>();

        final ArrayList<Move> moveList = new ArrayList<>();
        boolean first = true;
        for (;;) {
            moveList.clear();
            gameMap.updateMap(Networking.readLineIntoMetadata());

            if (first) {
                ArrayList<Move> open = opener(gameMap, playerID);
                first = false;
                //pener(gameMap, playerID, networking);
                Networking.sendMoves(open);
            } else {
                for (final Ship ship : gameMap.getMyPlayer().getShips().values()) {
                    if (ship.getDockingStatus() == Ship.DockingStatus.Undocked) {

                        Planet nearestPlanet = Util.nearestUnownedPlanet(ship,
                                gameMap);

                        if (nearestPlanet == null) {
                            nearestPlanet = nearestPlanet(ship, gameMap);
                        }
                        if (ship.canDock(nearestPlanet)) {
                            moveList.add(new DockMove(ship, nearestPlanet));
                            continue;
                        }

                        final ThrustMove newThrustMove = Navigation.navigateShipToDock(gameMap, ship, nearestPlanet, Constants.MAX_SPEED);
                        if (newThrustMove != null) {
                            moveList.add(newThrustMove);
                            continue;
                        }

                        //if no planets, attack ships
                        Ship nearestShip = nearestEnemyShip(ship, gameMap, playerID);
                        final ThrustMove newThrustMove2 = Navigation
                                .navigateShipTowardsTarget(gameMap, ship,
                                        ship.getClosestPoint(nearestShip),
                                        Constants.MAX_SPEED, true,
                                        Constants.MAX_NAVIGATION_CORRECTIONS,
                                        Math.PI/180.0 );
                        if (newThrustMove2 != null) {
                            moveList.add(newThrustMove2);
                            continue;
                        }
                    }
                }
                Networking.sendMoves(moveList);
            }
        }
    }

    /**
     * Moves the three opening ships to dock with the nearest planets
     * @param gameMap 2D gamemap
     * @param playerID My identification
     * @return ArrayList of moves to complete
     */
    private static ArrayList<Move> opener(GameMap gameMap, int playerID) {
        Ship ship1 = gameMap.getShip(playerID, 0);

        ArrayList<Move> toReturn = new ArrayList<>();
        ArrayList<Planet> nearestThree = openerHelper(ship1, gameMap);

        for (int i = 0; i < 3; i++) {
            Ship curShip = gameMap.getShip(playerID, i);
            if (curShip.canDock(nearestThree.get(i))) {
                toReturn.add(new DockMove(curShip, nearestThree.get(i)));
                continue;
            } else {
                final ThrustMove newThrustMove = Navigation.navigateShipToDock
                        (gameMap, curShip, nearestThree.get(i), Constants
                                .MAX_SPEED /
                                2);
                if (newThrustMove != null) {
                    toReturn.add(newThrustMove);
                    continue;
                }
            }
        }
        return toReturn;
    }

    /**
     * Given on ships location it produces an arraylist of the three nearest
     * planets
     * @param ship One of the three ships I start the game with
     * @param gameMap The map of the game
     * @return An ArrayList containing the three planets closest to the
     * ships starting location
     */
    private static ArrayList<Planet> openerHelper(Ship ship, GameMap gameMap) {
        ArrayList<Planet> toReturn = new ArrayList<>();
        Map<Double, Entity> entityMap = gameMap.nearbyEntitiesByDistance(ship);
        if (entityMap != null && !(entityMap.isEmpty())) {
            Double shortDist = null;
            int count = 0;
            for (Map.Entry<Double, Entity> entry : entityMap.entrySet()) {
                Entity ent = entry.getValue();
                if (!(ent instanceof Planet)) {
                    //skip this iteration
                    continue;
                } else {
                    Planet temp = (Planet) ent;
                    if (temp.isOwned()) {
                        //skip this iteration
                        continue;
                    }
                    if (count < 3) {
                        toReturn.add(temp);
                        count++;
                    } else {
                        break;
                    }
                }
            }
        }
        return toReturn;
    }

    private static Planet nearestPlanet(Ship ship, GameMap gameMap) {
        Planet nearest = null;
        Map<Double, Entity> entityMap = gameMap.nearbyEntitiesByDistance(ship);

        if (entityMap != null && !(entityMap.isEmpty())) {
            for (Map.Entry<Double, Entity> entry : entityMap.entrySet()) {
                Entity ent = entry.getValue();
                if (!(ent instanceof Planet)) {
                    //skip this iteration
                    continue;
                } else {
                    nearest = (Planet) ent;
                }
            }
        }
        return nearest;
    }

    private static Ship nearestEnemyShip(Ship ship, GameMap gameMap, int
            playerID) {
        Ship nearest = null;
        Map<Double, Entity> entityMap = gameMap.nearbyEntitiesByDistance(ship);

        if (entityMap != null && !(entityMap.isEmpty())) {
            for (Map.Entry<Double, Entity> entry : entityMap.entrySet()) {
                Entity ent = entry.getValue();
                if (!(ent instanceof Ship)) {
                    //skip this iteration
                    continue;
                }
                Ship temp = (Ship) ent;
                if (temp.getOwner() == playerID) {
                    continue;
                } else {
                    nearest = temp;
                }
            }
        }
        return nearest;

    }

}
