import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

/**
 * By Eli Bailey
 * Halite has no debugging so it is necessary to log to a text file
 */
public class Log {

    private BufferedWriter bufferedWriter;
    private FileWriter fileWriter;

    Log() {
        // The name of the file to open.
        String fileName = "temp.txt";

        try {
            // Assume default encoding.
            fileWriter = new FileWriter(fileName);

            // Always wrap FileWriter in BufferedWriter.
            bufferedWriter = new BufferedWriter(fileWriter);
        } catch (IOException ioex) {
            ioex.printStackTrace();
        }
    }

    Log(String name) {
        // The name of the file to open.
        String fileName = name;

        try {
            // Assume default encoding.
            fileWriter = new FileWriter(fileName);

            // Always wrap FileWriter in BufferedWriter.
            bufferedWriter = new BufferedWriter(fileWriter);
        } catch (IOException ioex) {
            ioex.printStackTrace();
        }
    }

    public boolean write(String input) {
        boolean successful = true;
        try {
            this.bufferedWriter.write(input);
        } catch (IOException e) {
            successful = false;
            e.printStackTrace();
            System.out.println("Logging failed to write");
        } finally {
            // Always close files.
            try {
                bufferedWriter.close();
                fileWriter.close();
            } catch (IOException ioex) {
                successful = false;
                System.out.println("Logging failed to close file");
            }
        }
        return successful;
    }
}
