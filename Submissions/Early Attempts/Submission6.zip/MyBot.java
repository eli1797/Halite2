import hlt.*;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class MyBot {

    public static void main(final String[] args) {
        final Networking networking = new Networking();
        final GameMap gameMap = networking.initialize("Tamagocchi");

        final ArrayList<Move> moveList = new ArrayList<>();
        for (;;) {
            moveList.clear();
            gameMap.updateMap(Networking.readLineIntoMetadata());

            for (final Ship ship : gameMap.getMyPlayer().getShips().values()) {
                if (ship.getDockingStatus() == Ship.DockingStatus.Undocked) {

                    Planet nearestPlanet = nearestUnownedPlanet(ship, gameMap);

                    if (ship.canDock(nearestPlanet)) {
                        moveList.add(new DockMove(ship, nearestPlanet));
                        break;
                    }

                    final ThrustMove newThrustMove = Navigation.navigateShipToDock(gameMap, ship, nearestPlanet, Constants.MAX_SPEED/2);
                    if (newThrustMove != null) {
                        moveList.add(newThrustMove);
                    }

                    break;
                } else if (ship.getDockingStatus() == Ship.DockingStatus.Docked) {
                    //the ship is docked
                    Planet parent = gameMap.getPlanet(ship.getDockedPlanet());
                    List<Integer> docked = parent.getDockedShips();
                    if (docked.size() > 2) {
                        //leave the planet
                        //@TODO: setup debug output to text file
                    }
                }
            }
            Networking.sendMoves(moveList);
        }
    }

    private static ArrayList<Planet> arrayListPlanets(GameMap gameMap) {
        Map<Integer, Planet> mapPlanets = gameMap.getAllPlanets();
        ArrayList<Planet> planetList = new ArrayList<>(mapPlanets.values());
        return planetList;
    }

    private static Planet nearestUnownedPlanet(Ship ship, GameMap gameMap) {
        Planet nearest = null;
        Map<Double, Entity> entityMap = gameMap.nearbyEntitiesByDistance(ship);

        if (entityMap != null && !(entityMap.isEmpty())) {
            Double shortDist = null;
            for (Map.Entry<Double, Entity> entry : entityMap.entrySet()) {
                Entity ent = entry.getValue();
                Double dist = entry.getKey();
                if (!(ent instanceof Planet)) {
                    //skip this iteration
                    continue;
                } else {
                    Planet temp = (Planet) ent;
                    if (temp.isOwned()) {
                        //skip this iteration
                        continue;
                    }
                    if (shortDist == null) {
                        shortDist = dist;
                        nearest = temp;
                    } else if (shortDist > dist) {
                        nearest = temp;
                    }
                }
            }
        }
        return nearest;
    }
}
