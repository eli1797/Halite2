import hlt.*;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class MyBot {

    public static void main(final String[] args) {
        final Networking networking = new Networking();
        final GameMap gameMap = networking.initialize("Tamagocchi");
        final int playerID = gameMap.getMyPlayerId();
        Map<Planet, Integer> squads = new TreeMap<>();

        final ArrayList<Move> moveList = new ArrayList<>();
        boolean first = true;
        for (;;) {
            moveList.clear();
            gameMap.updateMap(Networking.readLineIntoMetadata());

            if (first) {
                ArrayList<Move> open = opener(gameMap, playerID);
                first = false;
                Networking.sendMoves(open);
            } else {
                for (final Ship ship : gameMap.getMyPlayer().getShips().values()) {
                    if (ship.getDockingStatus() == Ship.DockingStatus.Undocked) {

                        Planet nearestPlanet = nearestUnownedPlanet(ship, gameMap);

                        if (nearestPlanet == null) {
                            nearestPlanet = nearestPlanet(ship, gameMap);
                        }
                        if (ship.canDock(nearestPlanet)) {
                            moveList.add(new DockMove(ship, nearestPlanet));
                            break;
                        }

                        final ThrustMove newThrustMove = Navigation.navigateShipToDock(gameMap, ship, nearestPlanet, Constants.MAX_SPEED / 2);
                        if (newThrustMove != null) {
                            moveList.add(newThrustMove);
                        }

                        break;
                    } else {
                        Planet parent = gameMap.getPlanet(ship.getDockedPlanet());
                        if (parent.getRemainingProduction() <= 0) {
                            //once production runs out move on
                        }

                    }
                }
                Networking.sendMoves(moveList);
            }
        }
    }

    private static ArrayList<Move> opener(GameMap gameMap, int playerID) {
        Ship ship1 = gameMap.getShip(playerID, 0);

        ArrayList<Move> toReturn = new ArrayList<>();
        ArrayList<Planet> nearestThree = openerHelper(ship1, gameMap);

        for (int i = 0; i < 3; i++) {
            Ship curShip = gameMap.getShip(playerID, i);
            if (curShip.canDock(nearestThree.get(i))) {
                toReturn.add(new DockMove(curShip, nearestThree.get(i)));
            } else {
                final ThrustMove newThrustMove = Navigation.navigateShipToDock
                        (gameMap, curShip, nearestThree.get(i), Constants
                                .MAX_SPEED /
                                2);
                if (newThrustMove != null) {
                    toReturn.add(newThrustMove);
                }
            }
        }
        return toReturn;
    }

    /**
     * Given on ships location it produces an arraylist of the three nearest
     * planets
     * @param ship One of the three ships I start the game with
     * @param gameMap The map of the game
     * @return An ArrayList containing the three planets closest to the
     * ships starting location
     */
    private static ArrayList<Planet> openerHelper(Ship ship, GameMap gameMap) {
        ArrayList<Planet> toReturn = new ArrayList<>();
        Map<Double, Entity> entityMap = gameMap.nearbyEntitiesByDistance(ship);
        if (entityMap != null && !(entityMap.isEmpty())) {
            Double shortDist = null;
            int count = 0;
            for (Map.Entry<Double, Entity> entry : entityMap.entrySet()) {
                Entity ent = entry.getValue();
                if (!(ent instanceof Planet)) {
                    //skip this iteration
                    continue;
                } else {
                    Planet temp = (Planet) ent;
                    if (temp.isOwned()) {
                        //skip this iteration
                        continue;
                    }
                    if (count < 3) {
                        toReturn.add(temp);
                        count++;
                    } else {
                        break;
                    }
                }
            }
        }
        return toReturn;
    }

    /**
     * Returns the nearest planet not owned by anyone
     * @param ship The ship that's looking for a nearby planet
     * @param gameMap The shared 2D playing board
     * @return Planet The closest unoccupied planet
     */
    private static Planet nearestUnownedPlanet(Ship ship, GameMap gameMap) {
        Planet nearest = null;
        Map<Double, Entity> entityMap = gameMap.nearbyEntitiesByDistance(ship);

        if (entityMap != null && !(entityMap.isEmpty())) {
            Double shortDist = null;
            for (Map.Entry<Double, Entity> entry : entityMap.entrySet()) {
                Entity ent = entry.getValue();
                Double dist = entry.getKey();
                if (!(ent instanceof Planet)) {
                    //skip this iteration
                    continue;
                } else {
                    Planet temp = (Planet) ent;
                    if (temp.isOwned()) {
                        //skip this iteration
                        continue;
                    }
                    if (shortDist == null) {
                        shortDist = dist;
                        nearest = temp;
                        //write to log
                        Log log = new Log();
                        log.write("Defined Planet");
                    } else if (shortDist > dist) {
                        nearest = temp;
                    }
                }
            }
        }
        return nearest;
    }

    private static Planet nearestPlanet(Ship ship, GameMap gameMap) {
        Planet nearest = null;
        Map<Double, Entity> entityMap = gameMap.nearbyEntitiesByDistance(ship);

        if (entityMap != null && !(entityMap.isEmpty())) {
            for (Map.Entry<Double, Entity> entry : entityMap.entrySet()) {
                Entity ent = entry.getValue();
                if (!(ent instanceof Planet)) {
                    //skip this iteration
                    continue;
                } else {
                    nearest = (Planet) ent;
                }
            }
        }
        return nearest;
    }

}
