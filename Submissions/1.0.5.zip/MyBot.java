import hlt.*;

import java.util.ArrayList;
import java.util.Map;
import java.util.TreeMap;

public class MyBot {

    public static void main(final String[] args) {
        final Networking networking = new Networking();
        final GameMap gameMap = networking.initialize("Tamagocchi");
        final int playerID = gameMap.getMyPlayerId();
        Map<Planet, Integer> squads = new TreeMap<>();

        final ArrayList<Move> moveList = new ArrayList<>();
        boolean first = true;
        for (;;) {
            moveList.clear();
            gameMap.updateMap(Networking.readLineIntoMetadata());

            if (first) {
                ArrayList<Move> open = Opener.opener(gameMap, playerID);
                first = false;
                Networking.sendMoves(open);
            } else {
                for (final Ship ship : gameMap.getMyPlayer().getShips().values()) {
                    if (ship.getDockingStatus() == Ship.DockingStatus.Undocked) {

                        Planet nearestPlanet = GenNav.nearestUnownedPlanet(ship,
                                gameMap);

                        if (nearestPlanet == null) {
                            nearestPlanet = GenNav.nearestPlanet(ship, gameMap);
                            DebugLog.addLog("Change to any nearby planet");
                        }
                        if (ship.canDock(nearestPlanet)) {
                            moveList.add(new DockMove(ship, nearestPlanet));
                            continue;
                        }

                        final ThrustMove newThrustMove = Navigation.navigateShipToDock(gameMap, ship, nearestPlanet, Constants.MAX_SPEED);
                        if (newThrustMove != null) {
                            moveList.add(newThrustMove);
                            continue;
                        }


                    }
                }
                Networking.sendMoves(moveList);
            }
        }
    }
}
